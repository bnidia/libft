/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: greita <greita@student.21-school.ru>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/17 09:03:44 by greita            #+#    #+#             */
/*   Updated: 2021/10/17 10:07:31 by greita           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	ft_isspace(char c)
{
	if (c == ' ' || c == '\n' || c == '\t'
		|| c == '\r' || c == '\f' || c == '\v')
		return (1);
	else
		return (0);
}

int	ft_atoi(const char *str)
{
	int		negative;
	int		result;
	int		num_length;

	negative = 1;
	result = 0;
	num_length = 1;
	while (ft_isspace(*str))
		str++;
	if (*str == '-')
	{
		negative = -1;
		str++;
	}
	else if (*str == '+')
		str++;
	while (*str >= '0' && *str <= '9' && num_length++)
		result = (result * 10) + (*str++ - 48);
	if (num_length - 1 > 10 && negative == -1)
		return (0);
	else if (num_length - 1 > 10)
		return (-1);
	return (negative * result);
}
