#!/bin/bash

cd ~/libftTester
make a
cd ~/libft
